# Free Auto Commodity Signals → Telegram (No PC needed)

Runs completely in the cloud on GitHub Actions (free).
Only strong signals (strength 3 & 4) are sent to your phone.

## One-time Setup (5 minutes)

### 1. Create GitHub account (if you don’t have)
Go to https://github.com and sign up (free).

### 2. Create a new repository
- Click **New repository**
- Name: `commodity-signals` (or any name)
- Keep it **Private** (recommended)
- Click Create repository

### 3. Upload these files
Upload the two files into the repository:
- `signals.py`
- `.github/workflows/signals.yml`  (create the folders if needed)

Easiest way:
- Click “uploading an existing file”
- Or use GitHub website to create the folders and paste the code

### 4. Add your Telegram secrets
1. In your repository go to **Settings → Secrets and variables → Actions**
2. Click **New repository secret**
3. Add these two secrets one by one:

   Name: `TELEGRAM_BOT_TOKEN`  
   Value: your bot token from @BotFather

   Name: `TELEGRAM_CHAT_ID`  
   Value: your chat id from @userinfobot

### 5. Done!
The workflow will now run automatically every 30 minutes on weekdays
and send strong signals to your Telegram.

You can also click **Actions → Auto Commodity Signals → Run workflow**
to test it immediately.

## Notes
- Completely free
- No PC required after setup
- Only strength ≥ 3 signals are sent
- Uses free Yahoo Finance data (direction highly correlated with MCX)
