#!/usr/bin/env python3
"""
Cloud Auto Commodity Signals → Telegram
Runs on GitHub Actions (free) – no PC needed
Only sends strength ≥ 3 signals
"""

import os
import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime
import requests
from ta.trend import EMAIndicator, ADXIndicator
from ta.momentum import RSIIndicator

COMMODITIES = {
    "GC=F": "Gold",
    "SI=F": "Silver",
    "CL=F": "Crude Oil",
    "NG=F": "Natural Gas",
    "HG=F": "Copper",
}

TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")
CHAT  = os.environ.get("TELEGRAM_CHAT_ID", "")

def supertrend(df, period=10, mult=3.0):
    high, low, close = df["High"], df["Low"], df["Close"]
    tr = pd.concat([high-low, (high-close.shift()).abs(), (low-close.shift()).abs()], axis=1).max(axis=1)
    atr = tr.ewm(span=period, adjust=False).mean()
    hl2 = (high + low) / 2
    upper, lower = hl2 + mult*atr, hl2 - mult*atr
    st = pd.Series(index=df.index, dtype=float)
    direction = pd.Series(index=df.index, dtype=int)
    st.iloc[0], direction.iloc[0] = upper.iloc[0], 1
    for i in range(1, len(df)):
        if close.iloc[i] > st.iloc[i-1]:
            direction.iloc[i] = 1
        elif close.iloc[i] < st.iloc[i-1]:
            direction.iloc[i] = -1
        else:
            direction.iloc[i] = direction.iloc[i-1]
        if direction.iloc[i] == 1:
            st.iloc[i] = max(lower.iloc[i], st.iloc[i-1]) if direction.iloc[i-1]==1 else lower.iloc[i]
        else:
            st.iloc[i] = min(upper.iloc[i], st.iloc[i-1]) if direction.iloc[i-1]==-1 else upper.iloc[i]
    return st, direction, atr

def get_signal(symbol, name):
    try:
        df = yf.download(symbol, period="5d", interval="15m", progress=False, auto_adjust=True)
        if df is None or df.empty or len(df) < 50:
            return None
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = [c[0] for c in df.columns]

        close, high, low, vol = df["Close"], df["High"], df["Low"], df["Volume"]
        st, direction, atr = supertrend(df)
        ema9 = EMAIndicator(close, 9).ema_indicator()
        ema21 = EMAIndicator(close, 21).ema_indicator()
        rsi = RSIIndicator(close, 14).rsi()
        adx = ADXIndicator(high, low, close, 14).adx()

        price = float(close.iloc[-1])
        d = int(direction.iloc[-1])
        prev_d = int(direction.iloc[-2])
        r = float(rsi.iloc[-1])
        a = float(adx.iloc[-1]) if not pd.isna(adx.iloc[-1]) else 0
        atr_val = float(atr.iloc[-1])

        signal, strength = "NEUTRAL", 0
        if d == 1 and ema9.iloc[-1] > ema21.iloc[-1] and r >= 48 and a >= 18:
            signal, strength = "BUY", 4 if prev_d == -1 else 3
        elif d == -1 and ema9.iloc[-1] < ema21.iloc[-1] and r <= 52 and a >= 18:
            signal, strength = "SELL", 4 if prev_d == 1 else 3

        if strength < 3:
            return None  # only strong

        sl_dist = atr_val * 1.5
        if "BUY" in signal:
            sl, tp = price - sl_dist, price + sl_dist * 3
        else:
            sl, tp = price + sl_dist, price - sl_dist * 3

        return {
            "name": name, "price": round(price, 2),
            "signal": signal, "strength": strength,
            "sl": round(sl, 2), "tp": round(tp, 2),
            "rsi": round(r, 1), "adx": round(a, 1)
        }
    except Exception as e:
        print(f"Error {symbol}: {e}")
        return None

def send(msg):
    if not TOKEN or not CHAT:
        print("No Telegram credentials")
        return
    try:
        r = requests.post(
            f"https://api.telegram.org/bot{TOKEN}/sendMessage",
            json={"chat_id": CHAT, "text": msg, "parse_mode": "HTML", "disable_web_page_preview": True},
            timeout=15
        )
        print("Telegram sent" if r.status_code == 200 else f"Telegram fail: {r.text}")
    except Exception as e:
        print(f"Telegram error: {e}")

def main():
    print(f"Scan started {datetime.utcnow()} UTC")
    results = []
    for sym, name in COMMODITIES.items():
        res = get_signal(sym, name)
        if res:
            results.append(res)

    now = datetime.now().strftime("%d-%b %H:%M IST")
    if not results:
        # Optional: uncomment next line if you also want "no signal" messages
        # send(f"<b>⚡ Commodity Signals</b>\n{now}\n\nNo strong setups right now.")
        print("No strong signals")
        return

    lines = [f"<b>⚡ Strong Commodity Signals</b>", f"{now}", ""]
    for r in results:
        emoji = "🟢" if "BUY" in r["signal"] else "🔴"
        lines.append(f"{emoji} <b>{r['name']}</b> {r['price']} → <b>{r['signal']}</b> (str {r['strength']})")
        lines.append(f"    SL {r['sl']}  |  TP {r['tp']}  (1:3)")
        lines.append(f"    RSI {r['rsi']}  ADX {r['adx']}")
    lines.append("")
    lines.append("<i>Free Yahoo proxy · Confirm on MCX · Not advice</i>")
    send("\n".join(lines))
    print(f"Sent {len(results)} strong signals")

if __name__ == "__main__":
    main()
